import * as React from 'react';
import { fetchJSON } from '../apis/api';
import type { BackendNotice, Notice } from '../data/notices';
import { mapBackendToNotice } from '../data/notices';

/** 응답 배열 꺼내기(래핑 방어) */
const unpackArray = (res: any): BackendNotice[] => {
  if (Array.isArray(res)) return res as BackendNotice[];
  if (Array.isArray(res?.items)) return res.items as BackendNotice[];
  if (Array.isArray(res?.postings)) return res.postings as BackendNotice[];
  if (Array.isArray(res?.data)) return res.data as BackendNotice[];
  if (Array.isArray(res?.content)) return res.content as BackendNotice[];
  if (Array.isArray(res?.list)) return res.list as BackendNotice[];
  return [];
};

/**
 * 마감 임박: /api/postings/closing-soon
 * - 서버가 주는 배열을 그대로 화면에 노출 (맵핑만 적용)
 * - 추가 필터/정렬/페이지 크롤링 없음
 */
export function useDue(_pageSize = 200, _maxPages = 50) {
  const [list, setList] = React.useState<Notice[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    const ac = new AbortController();
    setLoading(true);
    setError(null);
    setList([]);

    (async () => {
      try {
        const res = await fetchJSON('/api/postings/closing-soon', { signal: ac.signal });
        const raw: BackendNotice[] = unpackArray(res);

        // 가공 없이 맵핑만 적용
        const mapped: Notice[] = raw.map(mapBackendToNotice);

        setList(mapped);
        setLoading(false);

        // 디버그: 서버 실제 응답 확인
        console.log('[closing-soon][raw]', { count: raw.length, ids: raw.map(x => x.id) });
      } catch (e: any) {
        if (ac.signal.aborted) return;
        setError(e?.message ?? String(e));
        setList([]);
        setLoading(false);
        console.log('[closing-soon][error]', e);
      }
    })();

    return () => ac.abort();
  }, [_pageSize, _maxPages]); // 시그니처 유지(미사용)

  return { list, loading, error };
}
