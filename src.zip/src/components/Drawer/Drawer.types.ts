interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export type { DrawerProps };
