export interface LabelProps {
  children: React.ReactNode;
}
