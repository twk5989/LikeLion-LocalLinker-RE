export interface TitleProps {
  children: React.ReactNode;
}
