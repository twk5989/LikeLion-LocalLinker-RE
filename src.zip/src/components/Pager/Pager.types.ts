export type PagerProps = {
  page: number;
  totalPages: number;
  onChange: (page: number) => void;
};
