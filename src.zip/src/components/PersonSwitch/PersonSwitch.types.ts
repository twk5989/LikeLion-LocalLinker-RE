export type PersonSwitchProps = {
  personalOnly: boolean;
  onSwitchPerson: () => void;
};
