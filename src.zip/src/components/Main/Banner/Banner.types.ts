// src/components/Banner/Banner.types.ts
export type BannerProps = {
  title?: string;
  body?: string;
};
