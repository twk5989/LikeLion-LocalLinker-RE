interface BannerProps {
  title: string;
}

export type { BannerProps };
