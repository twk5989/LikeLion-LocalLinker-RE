interface HeaderProps {
  type: 'main' | 'detail' | 'chat';
  text?: string;
}

export type { HeaderProps };
