interface ChatOptionButtonProps {
  text: string;
  onClick: () => void;
}

export type { ChatOptionButtonProps };
