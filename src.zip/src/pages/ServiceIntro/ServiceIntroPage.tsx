import React from 'react';

function ServiceIntroPage() {
  return <div>ServiceIntroPage</div>;
}

export default ServiceIntroPage;
