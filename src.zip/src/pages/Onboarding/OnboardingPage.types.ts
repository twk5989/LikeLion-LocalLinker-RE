interface OnboardingPageProps {
  onNext: () => void;
}

export type { OnboardingPageProps };
