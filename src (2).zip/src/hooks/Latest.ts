// hooks/useLatest.ts
import * as React from 'react';
import { mockOrApiGet } from '../apis';               // ✅ 목업/실서버 토글
import { unpackArray } from '../utils/query';         // ✅ 응답 배열 안전 언팩
import { latestScore } from '../utils/dateScore';     // ✅ 시작일 기준 점수
import { mapBackendList } from '../mappers/notice';
import type { BackendNotice, Notice } from '../types/notices';
// (선택) 비자 값 정규화가 필요하면 사용
// import { normalizeVisa } from '../utils/visa';

type LatestFilters = { visa?: string };

async function fetchLatest(pageSize: number, visa?: string) {
  // const v = normalizeVisa(visa); // 필요 시 정규화
  const res = await mockOrApiGet(`/api/postings/latest`, {
    params: { size: pageSize, page: 0, visa }, // 백엔드 스펙 유지
  });
  return unpackArray(res) as BackendNotice[];
}

export function useLatest(pageSize = 200, _maxPages = 50, filters?: LatestFilters) {
  const [list, setList] = React.useState<Notice[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        setLoading(true);

        const raw = await fetchLatest(pageSize, filters?.visa);

        // ✅ 시작일 있는 것만, 현재와 가까운 순(작을수록 최신)
        const sorted = raw
          .filter(n => !!n.applyStartAt)
          .sort((a, b) => latestScore(a.applyStartAt) - latestScore(b.applyStartAt));

        if (!cancelled) setList(mapBackendList(sorted));
      } catch (e: any) {
        if (!cancelled) setError(e?.message ?? String(e));
        if (!cancelled) setList([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [pageSize, filters?.visa]);

  return { list, loading, error };
}
