export interface RadioLabelProps {
  children: React.ReactNode;
}
